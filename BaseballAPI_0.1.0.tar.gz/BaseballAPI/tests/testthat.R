library(testthat)
library(BaseballAPI)

test_check("BaseballAPI")
