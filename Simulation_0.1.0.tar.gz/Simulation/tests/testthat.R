library(testthat)
library(Simulation)

test_check("Simulation")
